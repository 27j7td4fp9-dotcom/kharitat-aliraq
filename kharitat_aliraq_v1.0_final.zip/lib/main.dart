
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const KharitatAlIraq());

class KharitatAlIraq extends StatelessWidget {
  const KharitatAlIraq({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'خارطة العراق',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF08111D),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1687FF), brightness: Brightness.dark),
      useMaterial3: true,
    ),
    home: const HomePage(),
  );
}

class Report {
  final String type;
  final LatLng point;
  final DateTime time;
  Report(this.type, this.point) : time = DateTime.now();
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final map = MapController();
  final search = TextEditingController();
  final tts = FlutterTts();
  LatLng center = const LatLng(33.3152, 44.3661);
  LatLng? me, destination;
  List<LatLng> route = [];
  List<Map<String, dynamic>> results = [];
  List<Report> reports = [];
  double distanceKm = 0;
  int minutes = 0;
  bool loading = false;
  bool navigating = false;
  String status = 'جاهز';

  @override
  void initState() {
    super.initState();
    _loadReports();
    tts.setLanguage('ar-IQ');
  }

  Future<void> _loadReports() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('reports') ?? [];
    // Local demo persistence. Production should use Firebase/Supabase/backend.
    setState(() => reports = []);
  }

  Future<void> locate() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      _msg('فعّل خدمة الموقع أولاً'); return;
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
      _msg('اسمح للتطبيق باستخدام الموقع'); return;
    }
    final p = await Geolocator.getCurrentPosition();
    final point = LatLng(p.latitude, p.longitude);
    setState(() { me = point; center = point; });
    map.move(point, 15);
  }

  Future<void> geocode(String q) async {
    if (q.trim().isEmpty) return;
    setState(() { loading = true; results = []; status = 'جاري البحث...'; });
    try {
      final uri = Uri.parse('https://nominatim.openstreetmap.org/search').replace(queryParameters: {
        'q': '$q, Iraq', 'format': 'json', 'limit': '8', 'accept-language': 'ar'
      });
      final r = await http.get(uri, headers: {'User-Agent': 'KharitatAlIraq/1.0'});
      final data = jsonDecode(r.body) as List;
      setState(() {
        results = data.map((x) => {
          'name': x['display_name'] ?? q,
          'lat': double.parse(x['lat'].toString()),
          'lon': double.parse(x['lon'].toString()),
        }).toList();
        status = results.isEmpty ? 'ما لكيت المكان' : 'اختار المكان';
      });
    } catch (_) {
      _msg('تعذر البحث حالياً');
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> buildRoute(LatLng target) async {
    LatLng start = me ?? center;
    setState(() { loading = true; destination = target; results = []; status = 'جاري حساب الطريق...'; });
    try {
      final url = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/${start.longitude},${start.latitude};${target.longitude},${target.latitude}'
      ).replace(queryParameters: {'overview': 'full', 'geometries': 'geojson'});
      final r = await http.get(url);
      final data = jsonDecode(r.body);
      final routeData = data['routes'][0];
      final coords = routeData['geometry']['coordinates'] as List;
      final line = coords.map<LatLng>((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble())).toList();
      setState(() {
        route = line;
        distanceKm = (routeData['distance'] as num).toDouble() / 1000;
        minutes = ((routeData['duration'] as num).toDouble() / 60).round();
        status = 'تم حساب الطريق';
      });
      if (line.isNotEmpty) map.fitCamera(CameraFit.coordinates(coordinates: line, padding: const EdgeInsets.all(70)));
    } catch (_) {
      _msg('تعذر حساب الطريق. جرّب مرة ثانية.');
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> startNavigation() async {
    if (destination == null) return;
    setState(() => navigating = true);
    await tts.speak('بدأنا الملاحة. المسافة ${distanceKm.toStringAsFixed(1)} كيلومتر، والوقت التقريبي $minutes دقيقة.');
  }

  void report(String type) {
    final p = me ?? center;
    setState(() => reports.add(Report(type, p)));
    Navigator.pop(context);
    _msg('تم إرسال بلاغ: $type');
  }

  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s, textDirection: TextDirection.rtl)));

  void reportSheet() => showModalBottomSheet(
    context: context, backgroundColor: const Color(0xFF101D2B),
    builder: (_) => SafeArea(child: Padding(
      padding: const EdgeInsets.all(18),
      child: Directionality(textDirection: TextDirection.rtl, child: Wrap(
        spacing: 10, runSpacing: 10,
        children: ['حادث مروري','ازدحام','حفرة','طريق مغلق','سيطرة أمنية','رادار','مركبة متعطلة']
          .map((x) => ActionChip(label: Text(x), onPressed: () => report(x))).toList(),
      )),
    )),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        FlutterMap(
          mapController: map,
          options: MapOptions(initialCenter: center, initialZoom: 6.2),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.kharitat.aliraq',
            ),
            if (route.isNotEmpty) PolylineLayer(polylines: [
              Polyline(points: route, strokeWidth: 6, color: const Color(0xFF1687FF)),
            ]),
            MarkerLayer(markers: [
              if (me != null) Marker(point: me!, width: 48, height: 48, child: const Icon(Icons.my_location, color: Colors.blue, size: 38)),
              if (destination != null) Marker(point: destination!, width: 48, height: 48, child: const Icon(Icons.location_pin, color: Colors.red, size: 44)),
              ...reports.map((r) => Marker(point: r.point, width: 40, height: 40,
                child: Icon(_reportIcon(r.type), color: Colors.orange, size: 30))),
            ]),
          ],
        ),
        Positioned(top: 48, left: 14, right: 14, child: _searchBox()),
        if (results.isNotEmpty) Positioned(top: 108, left: 14, right: 14, child: _results()),
        if (route.isNotEmpty) Positioned(left: 14, right: 14, bottom: 118, child: _routeCard()),
        Positioned(right: 14, bottom: 190, child: FloatingActionButton(
          heroTag: 'loc', backgroundColor: const Color(0xFF102235), onPressed: locate, child: const Icon(Icons.my_location))),
        Positioned(left: 0, right: 0, bottom: 105, child: Center(child: FloatingActionButton(
          heroTag: 'add', backgroundColor: const Color(0xFF1687FF), onPressed: reportSheet, child: const Icon(Icons.add)))),
        Positioned(left: 10, right: 10, bottom: 10, child: _navBar()),
        if (loading) const Positioned(top: 115, left: 0, right: 0, child: LinearProgressIndicator()),
      ]),
    );
  }

  IconData _reportIcon(String s) {
    if (s.contains('حادث')) return Icons.car_crash;
    if (s.contains('ازدحام')) return Icons.traffic;
    if (s.contains('حفرة')) return Icons.warning;
    if (s.contains('مغلق')) return Icons.block;
    if (s.contains('سيطرة')) return Icons.local_police;
    if (s.contains('رادار')) return Icons.radar;
    return Icons.build;
  }

  Widget _searchBox() => Row(children: [
    Container(width: 48, height: 48, decoration: _dec(), child: IconButton(icon: const Icon(Icons.menu), onPressed: () => _msg('القائمة الرئيسية'))),
    const SizedBox(width: 8),
    Expanded(child: TextField(
      controller: search, textDirection: TextDirection.rtl,
      decoration: InputDecoration(hintText: 'وين تريد تروح؟', prefixIcon: const Icon(Icons.search),
        suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: () => geocode(search.text)),
        filled: true, fillColor: const Color(0xF20D1A28), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)),
      onSubmitted: geocode,
    )),
  ]);

  Widget _results() => Card(
    color: const Color(0xF20D1A28),
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 280),
      child: ListView.builder(shrinkWrap: true, itemCount: results.length, itemBuilder: (_, i) {
        final x = results[i];
        return ListTile(
          leading: const Icon(Icons.place, color: Colors.blue),
          title: Text(x['name'], maxLines: 2, overflow: TextOverflow.ellipsis, textDirection: TextDirection.rtl),
          onTap: () => buildRoute(LatLng(x['lat'], x['lon'])),
        );
      }),
    ),
  );

  Widget _routeCard() => Card(
    color: const Color(0xF20D1A28),
    child: Padding(padding: const EdgeInsets.all(14), child: Directionality(textDirection: TextDirection.rtl, child: Row(
      children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${distanceKm.toStringAsFixed(1)} كم', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text('حوالي $minutes دقيقة • $status'),
        ])),
        ElevatedButton.icon(onPressed: startNavigation, icon: const Icon(Icons.navigation), label: Text(navigating ? 'الملاحة شغالة' : 'ابدأ')),
        if (navigating) IconButton(onPressed: () async { await tts.stop(); setState(() => navigating = false); }, icon: const Icon(Icons.stop_circle)),
      ],
    ))),
  );

  Widget _navBar() => Container(
    decoration: _dec(),
    child: NavigationBar(
      backgroundColor: Colors.transparent, selectedIndex: 0,
      onDestinationSelected: (i) { if (i == 1) _msg('التنبيهات: ${reports.length} بلاغ محلي'); if (i == 2) _msg('الإعدادات'); },
      destinations: const [
        NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'الخريطة'),
        NavigationDestination(icon: Icon(Icons.notifications_none), label: 'التنبيهات'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'الإعدادات'),
      ],
    ),
  );

  BoxDecoration _dec() => BoxDecoration(color: const Color(0xF20D1A28), borderRadius: BorderRadius.circular(18));
}
